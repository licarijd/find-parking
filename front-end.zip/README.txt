Justin Licari, 1313781

Design Choice: In parking, html, rather than having a single table, I have one for each marker on the map. When a user clicks a marker, all data on that parking spot is displayed. I did this because I felt it looked more organized to have all parking spot data in one place, and was more aesthetically pleasing to use the most page space possible for the embedded map.

